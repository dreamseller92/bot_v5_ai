import time
from misc.common_scripts import where_i_am, full_or_not, full_or_not_2
from actions.common_actions import find_and_click_image, reset_position_in_city

def dig(device):


    k = True
    while k:
        screenshot = device.screencap()
        if where_i_am(screenshot):
            time.sleep(2)
            device.shell(f"input tap 60 899")
        time.sleep(1)
        device.shell(f"input tap 509 763")
        time.sleep(1)
        find_and_click_image(device, 'base_data\\img\\dig\\go1.png')
        time.sleep(1)
        find_and_click_image(device, 'base_data\\img\\dig\\dig.png')
        find_and_click_image(device, 'base_data\\img\\dig\\dig.png')

        screenshot = device.screencap()
        if full_or_not(screenshot):
            time.sleep(2)
            device.shell(f"input tap 60 899")
            k = False
        if full_or_not_2(screenshot):
            time.sleep(2)
            device.shell(f"input tap 60 899")
            k = False

        time.sleep(0.5)
        find_and_click_image(device, 'base_data\\img\\dig\\set_out.png')

    time.sleep(2)
    device.shell(f"input tap 60 899")