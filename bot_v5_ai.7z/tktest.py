import tkinter as tk
from tkinter import ttk

class InstanceManager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Multi-Instance Manager")

        self.tree = ttk.Treeview(self, columns=("name", "os_version"), show="headings")
        self.tree.heading("name", text="Name")
        self.tree.heading("os_version", text="OS Version")

        instances = [
            ("1220_16_steel", "Pie 64-bit"),
            ("1220_17_steel", "Pie 64-bit"),
            ("1220_18_steel", "Pie 64-bit"),
            # Add more instances as needed
        ]

        for instance in instances:
            self.tree.insert("", tk.END, values=instance)

        self.tree.pack(fill=tk.BOTH, expand=True)

        buttons_frame = tk.Frame(self)
        buttons_frame.pack(fill=tk.X)

        create_button = tk.Button(buttons_frame, text="Create New Instance", command=self.create_instance)
        create_button.pack(side=tk.LEFT, padx=5, pady=5)

        stop_all_button = tk.Button(buttons_frame, text="Stop All Instances", command=self.stop_all_instances)
        stop_all_button.pack(side=tk.LEFT, padx=5, pady=5)

    def create_instance(self):
        print("Create New Instance")

    def stop_all_instances(self):
        print("Stop All Instances")

if __name__ == "__main__":
    app = InstanceManager()
    app.mainloop()
