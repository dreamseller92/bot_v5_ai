import os
import json
import time
import easyocr
from ppadb.client import Client as AdbClient
from PIL import Image, ImageDraw
import io
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import cv2
# Подключение к устройству BlueStacks

def connect_to_device():
    client = AdbClient(host="127.0.0.1", port=5037)
    os.system("adb connect 127.0.0.1:5575")
    device = client.device("127.0.0.1:5575")
    if device:
        print("Connected to BlueStacks device")
    else:
        print("Failed to connect to BlueStacks device")
    return device
# Функция для создания скриншота
def get_screenshot(device):
    screenshot = device.screencap()
    image = Image.open(io.BytesIO(screenshot))
    return image
# Функция для имитации нажатия на экран
def tap_screen(device, x, y):
    device.shell(f'input tap {x} {y}')
    print(f"Tapped on ({x}, {y})")
# Определение простой модели
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc1 = nn.Linear(28*28, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 10)

    def forward(self, x):
        x = torch.flatten(x, 1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x
# Инициализация модели, критерия и оптимизатора
model = SimpleModel()
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)
# Сохранение состояния модели и оптимизатора
def save_model(model, optimizer, path="model.pth"):
    torch.save({
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
    }, path)
    print("Model saved")
# Сохранение состояния модели и оптимизатора
def save_model(model, optimizer, path="model.pth"):
    torch.save({
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
    }, path)
    print("Model saved")
# Загрузка состояния модели и оптимизатора
def load_model(model, optimizer, path="model.pth"):
    if os.path.isfile(path):
        checkpoint = torch.load(path)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        print("Model loaded")
    else:
        print("No saved model found")


# Функция для начального обучения модели с использованием скриншотов
def initial_train_with_screenshots(device, num_samples=10):
    model.train()
    for _ in range(num_samples):
        image = get_screenshot(device)
        X_train = preprocess_image(image)
        y_train = torch.tensor([0], dtype=torch.long)  # Здесь нужно указать реальные метки для обучения
        optimizer.zero_grad()
        outputs = model(X_train)
        loss = criterion(outputs, y_train)
        loss.backward()
        optimizer.step()
    print("Initial training complete")
# Преобразование изображения и нормализация
def preprocess_image(image):
    image = image.convert("L")  # Конвертация в черно-белое изображение
    image = image.resize((28, 28))  # Изменение размера
    image_np = np.array(image, dtype=np.float32) / 255.0  # Нормализация
    image_tensor = torch.tensor(image_np).unsqueeze(0).unsqueeze(0)  # Преобразование в тензор
    return image_tensor
# Обработка скриншота и получение предсказания модели
def analyze_screenshot(device):
    image = get_screenshot(device)
    image_tensor = preprocess_image(image)
    model.eval()
    with torch.no_grad():
        output = model(image_tensor)
    prediction = torch.argmax(output, dim=1)
    return prediction.item(), image
# Обновление модели новыми данными
def update_model(X_new, y_new):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_new)
    loss = criterion(outputs, y_new)
    loss.backward()
    optimizer.step()
    print("Model updated with new data")
# Инициализация EasyOCR
reader = easyocr.Reader(['en', 'ru'], gpu=True)
# Поиск кнопок и распознавание текста на экране
def find_buttons_and_text(image):
    screenshot_cv = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    gray_screenshot = cv2.cvtColor(screenshot_cv, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray_screenshot, (5, 5), 0)
    edged = cv2.Canny(blurred, 50, 150)
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    buttons = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w > 50 and h > 20:  # Пример фильтрации по размеру
            buttons.append((x, y, w, h))

    # Распознавание текста
    text_results = reader.readtext(screenshot_cv)
    text_elements = []
    for (bbox, text, prob) in text_results:
        if prob > 0.6:  # Фильтрация по уверенности
            (x_min, y_min), (x_max, y_max) = bbox[0], bbox[2]
            x, y, w, h = int(x_min), int(y_min), int(x_max - x_min), int(y_max - y_min)
            text_elements.append({
                'text': text,
                'x': x,
                'y': y,
                'width': w,
                'height': h
            })

    return buttons, text_elements
# Пример функции для перехода по меню
def navigate_menu(device, buttons):
    for (x, y, w, h) in buttons:
        center_x = x + w // 2
        center_y = y + h // 2
        device.shell(f'input tap {center_x} {center_y}')
        print(f"Tapped on ({center_x}, {center_y})")
        time.sleep(1)  # Пауза для обновления интерфейса
# Сохранение карты UI в формате JSON
def save_ui_map(ui_map, path="ui_map.json"):
    with open(path, "w") as f:
        json.dump(ui_map, f, indent=4, ensure_ascii=False)
    print("UI map saved")


# Взаимодействие с пользователем и разметка скриншота
def user_annotation(image, buttons):
    draw = ImageDraw.Draw(image)
    annotations = []
    for idx, (x, y, w, h) in enumerate(buttons):
        sub_image = image.crop((x, y, x + w, y + h))
        sub_image.show()
        annotation = input(f"What is shown at button {idx + 1}? ")
        annotations.append(annotation)

    return annotations
# Основная функция
def main():
    # Подключение к устройству
    device = connect_to_device()
    print("Connected to BlueStacks device")

    # Загрузка модели, если она существует
    load_model(model, optimizer)

    # Начальное обучение модели с использованием скриншотов
    initial_train_with_screenshots(device, num_samples=10)

    ui_map = []

    # Основной цикл анализа скриншотов и онлайн-обучения
    while True:
        # Получение предсказания модели и скриншота
        prediction, image = analyze_screenshot(device)
        print(f"Prediction: {prediction}")
        # Поиск кнопок и распознавание текста на экране
        buttons, text_elements = find_buttons_and_text(image)

        if buttons:
            print("Buttons found on the screen.")

            # Разметка скриншота пользователем
            annotations = user_annotation(image, buttons)

            # Переход по меню с использованием найденных кнопок
            navigate_menu(device, buttons)

            # Обновление нового изображения после перехода по меню
            time.sleep(1)  # Пауза для обновления интерфейса
            image = get_screenshot(device)
            buttons, text_elements = find_buttons_and_text(image)
            # [_{{{CITATION{{{_1{](https://github.com/RoryShao/master/tree/abca192b114dc37eee8d9d31941d2678b5025ae8/Knowledge%20Distillation%2FVanillaKD%2FStudent.py)

            for idx, button in enumerate(buttons):
                ui_map.append({
                    "x": button[0],
                    "y": button[1],
                    "width": button[2],
                    "height": button[3],
                    "description": annotations[idx]
                })

            for text_element in text_elements:
                ui_map.append({
                    "text": text_element['text'],
                    "x": text_element['x'],
                    "y": text_element['y'],
                    "width": text_element['width'],
                    "height": text_element['height']
                })

            # Сохранение карты UI
                save_ui_map(ui_map)
        else:
             print("No buttons found.")

        # Обновление модели с новыми данными (пример использования)
        X_new = preprocess_image(image)
        y_new = torch.tensor([1], dtype=torch.long)  # Метка для нового скриншота (это должно быть реальное значение)
        update_model(X_new, y_new)

        # Сохранение модели после обновления
        save_model(model, optimizer)

if __name__ == "__main__":
    main()
