# "C:\Program Files\WindowsApps\Microsoft.Copilot_1.24112.129.0_x64__8wekyb3d8bbwe\CopilotNative.exe"

import time
import subprocess
import pygetwindow as gw
from PIL import ImageGrab
import pygetwindow as gw
import pyautogui

# Получение всех окон на рабочем столе
# windows = gw.getAllWindows()
#
# # Вывод названий всех окон
# for window in windows:
#     print(window.title)
# Запуск приложения
app_path = "C:\\Program Files\\WindowsApps\\Microsoft.Copilot_1.24112.129.0_x64__8wekyb3d8bbwe\\CopilotNative.exe"
subprocess.Popen(app_path)

# Получение окна приложения
windows = gw.getWindowsWithTitle('Microsoft Copilot: ваш помічник із ШІ')
if windows:
    app_window = windows[0]
else:
    print("Окно приложения не найдено!")
    exit()

# Получение размера окна
left, top, right, bottom = app_window.left, app_window.top, app_window.right, app_window.bottom
print(f"Размер окна: ({left}, {top}, {right}, {bottom})")

# Создание скриншота области окна
screenshot = ImageGrab.grab(bbox=(left, top, right, bottom))
screenshot.save('screenshot.png')

print("Скриншот сохранен как screenshot.png")
# Ожидание активизации окна
time.sleep(2)
# Ввод текста в активное окно
text_to_type = "Ваш текст здесь"
pyautogui.typewrite(text_to_type)
# print("Текст введен!")

