import random

from ppadb.client import Client as AdbClient
import time
import os
from icecream import ic

import concurrent.futures

from misc import run_and_kill_instances as raki
from misc.common_scripts import where_i_am, get_instance_dict,this_fucking_game_run_or_not
from actions.common_actions import find_and_click_image
from misc.ports_ex.get_bluestack_adb_ports import get_instanses_data
from actions.dig import dig
from actions.comander_skills import harvest, al_tech
import actions.common_actions as ca
import actions.colect_res as cr

# Подключение к Bluestacks через ppadb
get_instanses_data()
client = AdbClient(host="127.0.0.1", port=5037)

instance_queue_1143_steel = ["Pie64_51", "Pie64_52", "Pie64_53", "Pie64_54", "Pie64_55", "Pie64_57", "Pie64_58", "Pie64_59",
                  "Pie64_60", "Pie64_56", "Pie64_63", "Pie64_64", "Pie64_65", "Pie64_66", "Pie64_67"]

instance_queue_1220_oil = [ "Pie64_12", "Pie64_11", "Pie64_16", "Pie64_14", "Pie64_33", "Pie64_79", "Pie64_80", "Pie64_81", "Pie64_82", "Pie64_83", "Pie64_84", "Pie64_85", "Pie64_86", "Pie64_87", "Pie64_88"]
max_workers = 2

instance_names = [
    "Pie64_47",
    "Pie64_26",
    "Pie64_44",
    "Pie64_48",
    "Pie64_25",
    "Pie64_22",
    "Pie64_7",
    "Pie64_21",
    "Pie64_8",
    "Pie64_68",
    "Pie64_18",
    "Pie64_29",
    "Pie64_15",
    "Pie64_27",
    "Pie64_36",
    "Pie64_14",
    "Pie64_33",
    "Pie64_16",
    "Pie64_11",
    "Pie64_35",
    "Pie64_12",
    "Pie64_79",
    "Pie64_80",
    "Pie64_81",
    "Pie64_82",
    "Pie64_83",
    "Pie64_84",
    "Pie64_85",
    "Pie64_86",
    "Pie64_87",
    "Pie64_88"
]


instance_dict = get_instance_dict()
instances = list(instance_dict.keys())

from ppadb.client import Client as AdbClient

# Функция для выполнения действий в инстансе
def perform_actions(instance):
    name = instance_dict[instance]["Name"]
    port = instance_dict[instance]["port"]

    time.sleep(random.randint(1, 3))
    raki.run_instance(instance) #run process

    while True:
        time.sleep(10)
        try:
            os.system("adb connect 127.0.0.1:" + port)
            device = client.device(f'127.0.0.1:{port}')
            screenshot = device.screencap()
            if this_fucking_game_run_or_not(screenshot):
                template_path = 'main_ico.png'
                find_and_click_image(device,template_path)

            if where_i_am(screenshot):
                break


        except Exception as e:
            print(e)


    random.randint(1, 15)
    harvest(device)
    time.sleep(5)

    cr.collect_res(device)
    time.sleep(5)

    al_tech(device)
    time.sleep(5)
    dig(device)


    raki.kill_instance(name) # kill_process


def main():
    instance_queue = list(instances)  # Копируем список инстансов для работы с ним
    # instance_queue = instance_queue_1220_oil
    # instance_queue = instance_queue_1143_steel
    # instance_queue = instance_names[::1]

    #
    #instance_queue = ["Pie64_38"]ё 
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(perform_actions, instance) for instance in
                   instance_queue[:max_workers]}  # Запуск первых двух задач
        instance_queue = instance_queue[max_workers:]  # Оставшиеся задачи

        while futures:
            done, _ = concurrent.futures.wait(futures, return_when=concurrent.futures.FIRST_COMPLETED)

            for future in done:
                try:
                    result = future.result()
                except Exception as exc:
                    print(f'Задача вызвала исключение: {exc}')
                    return  # Ожидание и прекращение запуска новых задач в случае исключения

                futures.remove(future)

                if instance_queue:
                    instance = instance_queue.pop(0)
                    futures.add(executor.submit(perform_actions, instance))

    print("Все инстансы завершены")


if __name__ == "__main__":
    main()
