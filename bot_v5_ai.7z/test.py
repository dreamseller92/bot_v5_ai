import random

from ppadb.client import Client as AdbClient
import time
import os
from icecream import ic

import concurrent.futures

from misc import run_and_kill_instances as raki
from misc.common_scripts import where_i_am, get_instance_dict, get_full_instance_dict
import config

from actions.dig import dig
from actions.comander_skills import harvest, al_tech
import actions.common_actions as ca
import actions.colect_res as cr

# Подключение к Bluestacks через ppadb

client = AdbClient(host="127.0.0.1", port=5037)



# instance_dict = get_instance_dict(config.nation)
instance_dict = get_full_instance_dict()
instances = list(instance_dict.keys())




# Имя пакета приложения и основной активности
package_name = "com.camelgames.aoz"
main_activity = ".MainActivity"

# Функция для проверки, запущено ли приложение
def is_app_running(package,device):
    output = device.shell(f"pidof {package}")
    return bool(output.strip())

# Функция для запуска приложения
def start_app(package, activity,device):
    device.shell(f"am start -n {package}/{activity}")

# Проверка и запуск приложения при необходимости


# Функция для выполнения действий в инстансе
def perform_actions(instance):
    name = instance_dict[instance]["Name"]
    port = instance_dict[instance]["port"]

    time.sleep(random.randint(1, 3))
    raki.run_instance(instance) #run process

    while True:
        time.sleep(10)
        try:
            os.system("adb connect 127.0.0.1:" + port)
            device = client.device(f'127.0.0.1:{port}')
            if not is_app_running(package_name,device):
                print(f"{name}: Приложение не запущено. Запускаю приложение...")
                start_app(package_name, main_activity,device)
            else:
                print(f"{name}: Приложение уже запущено.")

            screenshot = device.screencap()
            if where_i_am(screenshot):
                break
        except Exception as e:
            print(e)


    random.randint(1, 15)
    # harvest(device)
    # time.sleep(5)
    al_tech(device)

    # cr.collect_res(device)
    time.sleep(5)
    #

    # time.sleep(5)
    # dig(device)


    # raki.kill_instance(name) # kill_process


def main():
    # instance_queue = list(instances)  # Копируем список инстансов для работы с ним

    # instance_queue = instance_queue_1220_oil
    # instance_queue = instance_queue_1143_steel
    instance_queue = ['Pie64_3', 'Pie64_4']

    with concurrent.futures.ThreadPoolExecutor(max_workers=config.max_workers) as executor:
        futures = {executor.submit(perform_actions, instance) for instance in
                   instance_queue[:config.max_workers]}  # Запуск первых двух задач
        instance_queue = instance_queue[config.max_workers:]  # Оставшиеся задачи

        while futures:
            done, _ = concurrent.futures.wait(futures, return_when=concurrent.futures.FIRST_COMPLETED)

            for future in done:
                try:
                    result = future.result()
                except Exception as exc:
                    print(f'Задача вызвала исключение: {exc}')
                    return  # Ожидание и прекращение запуска новых задач в случае исключения

                futures.remove(future)

                if instance_queue:
                    instance = instance_queue.pop(0)
                    futures.add(executor.submit(perform_actions, instance))

    print("Все инстансы завершены")


if __name__ == "__main__":
    main()
