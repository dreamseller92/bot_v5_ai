import subprocess
import time
import random
import os


def get_pid_by_label(app_name, label):
    result = subprocess.run(['tasklist', '/v', '/fo', 'csv'], capture_output=True, text=True, encoding='utf-8', errors='ignore')
    output = result.stdout
    for line in output.splitlines():
        splited_lines = line.split(',')
        if splited_lines[0].replace('"', '') == app_name:
            if splited_lines[-1].replace('"', '') == label:
                return int(splited_lines[1].split('"')[1])
    return



def kill_instance(name):
    pid = get_pid_by_label('HD-Player.exe',name)
    subprocess.run(['taskkill', '/PID', str(pid), '/F'])

def run_instance(instance):
    time.sleep(random.randint(5, 10))
    command = f'start "" "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe" --instance {instance} --cmd launchAppWithBsx --package "com.camelgames.aoz" --source desktop_shortcut'
    os.system(command)