MimMetaData_dir = 'Z:\\BlueStacks_nxt\\Engine\\UserData\\MimMetaData.json'
bluestacks_conf_dir = 'Z:\\BlueStacks_nxt\\bluestacks.conf'