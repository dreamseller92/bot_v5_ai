from PyBlueStacksPlayer import BlueStacksPlayer

# Создание экземпляра BlueStacksPlayer
bs_player = BlueStacksPlayer(adb_host='127.0.0.1', adb_port=5037)

# Запуск приложения
bs_player.launch_app('com.example.app')

# Завершение сессии
bs_player.end_session()
